<?php
    session_start();
    include_once "conexao.php";
    $dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

    $query_usuario = "INSERT INTO emprestimos (id, titulo ,estoque) VALUES (:id, :titulo,:estoque)";
    $cad_usuario = $conn->prepare($query_usuario);
    $cad_usuario->bindParam(':nome', $dados['id'], PDO::PARAM_STR);
    $cad_usuario->bindParam(':menu', $dados['titulo'], PDO::PARAM_STR);
    $cad_usuario->bindParam(':qntd', $dados['estoque'], PDO::PARAM_STR);
    echo   $dados['id']; 
     echo   $dados['titulo']; 
     echo   $dados['estoque']; 
    
    $query_usuario = "INSERT INTO usuarios (id, nome) VALUES (:id, :nome)";
$cad_usuario = $conn->prepare($query_usuario);
$cad_usuario->bindParam(':id', $dados['id'], PDO::PARAM_STR);
$cad_usuario->bindParam(':nome', $dados['nome'], PDO::PARAM_STR);
$cad_usuario->execute();
echo $dados['id'];
echo $dados['nome'];

    try {
        $cad_usuario->execute();   
    } catch (Exception $e) {
        echo 'Exceção capturada: ',  $e->getMessage(), "\n";
    }finally{
        $_SESSION['msg'] = "<p style='color: green;'>Usuário cadastrado com sucesso!</p>";
    }

    header("Location: index.php");
?>