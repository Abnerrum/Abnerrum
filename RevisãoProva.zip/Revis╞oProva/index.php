<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        form {
            width: 300px;
            margin: 20px auto;
            padding: 20px;
            border: 2px solid #007bff;
            border-radius: 5px;
        }
        form input, form select, form button {
            width: calc(100% - 10px);
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 3px;
        }
        form button {
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
    </style>
</head>
<body>
    <form action='processo.php' method='POST'>
        <input type='text' name='nome' placeholder="Nome" required>
        <input type='number' name='qntd' placeholder='Quantidade' required>
        <select name='menu'>
            <option value='' disabled selected>Livros</option>
            <?php
            include_once "conexao.php";
            $query_end = "SELECT * FROM livros";
            $lista = $conn->prepare($query_end);
            $lista->execute();
            $lista = $lista->fetchAll(PDO::FETCH_ASSOC);

            foreach ($lista as $row) {
                echo "<option value='{$row['id']}'>{$row['titulo']}</option>";
            }
            ?>
        </select>
        <button type='submit'>Solicitar</button>
    </form>

    <!-- Restante do código -->
</body>
</html>
