<?php
include "conexao.php";

$query = "SELECT V.cpf, P.nome, V.data FROM venda V JOIN produto P ON V.id_produto = P.id";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row['cpf'] . "</td><td>" . $row['nome'] . "</td><td>" . $row['data'] . "</td></tr>";
    }
} else {
    echo "Nenhum resultado encontrado.";
}

$conn->close();
?>
