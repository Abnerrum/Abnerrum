<!DOCTYPE html>
<html lang="pt-br">  <head>
    <title>Cadastrar Venda</title>
    <style>
        
        table {
            border-collapse: collapse; 
            width: 100%; 
        }
        th, td {
            padding: 8px; 
            border: 1px solid #ddd; 
        }
        label {
            display: block; 
            margin-bottom: 5px;
        }
        input[type="text"],
        input[type="date"] {
            width: 100%; 
            padding: 5px; 
            border: 1px solid #ccc; 
        }
        input[type="submit"] {
            padding: 10px 20px; 
            background-color: #4CAF50; 
            color: white; 
            border: none; 
            border-radius: 5px; 
            cursor: pointer; 
        }
    </style>
</head>
<body>
    <h1>Cadastrar Venda</h1>
    <form action="inserte.php" method="POST">
        <label for="data">Data:</label>
        <input type="date" id="data" name="data" required><br>

        <label for="cpf">CPF:</label>
        <input type="text" id="cpf" name="cpf" maxlength="14" required><br>  <label for="id_produto">Produto:</label>
        <select name="id_produto" id="id_produto" required>
            <?php include "produtos.php"; ?>
        </select><br>

        <input type="submit" value="Cadastrar">
    </form>

    <h1>Vendas</h1>
    <table>
        <tr>
            <th>CPF</th>
            <th>NOME DO PRODUTO</th>
            <th>DATA DA COMPRA</th>
        </tr>
        <?php include "vendas.php"; ?>
    </table>
</body>
</html>
