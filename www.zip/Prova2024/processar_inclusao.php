<?php
session_start();
include_once "conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_banco = $_POST["Banco"]; // Alterado para o nome correto do campo
    $valor = $_POST["valor"];

    $stmt = $conn->prepare("INSERT INTO clientes (id_banco, valor) VALUES (:id_banco, :valor)"); // Corrigido o nome da tabela para clientes
    $stmt->bindParam(":id_banco", $id_banco, PDO::PARAM_INT); // Corrigido o nome do parâmetro
    $stmt->bindParam(":valor", $valor, PDO::PARAM_STR);
    $stmt->execute();

    $_SESSION['msg'] = "Inclusão realizada com sucesso!";
    header("Location: index.php");
} else {
    $_SESSION['msg'] = "Requisição inválida.";
    header("Location: index.php");
}
?>
