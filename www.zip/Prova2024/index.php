<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inclusão de Banco</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5; /* Cor de fundo semelhante a um formulário de banco */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #fff; /* Cor de fundo do contêiner */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Sombra */
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333; /* Cor do texto */
        }

        form {
            max-width: 400px;
            margin: 0 auto;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: #555; /* Cor do texto */
        }

        select,
        input[type="text"],
        button {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc; /* Cor da borda */
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            background-color: #007bff; /* Cor do botão */
            color: #fff; /* Cor do texto do botão */
            cursor: pointer;
            transition: background-color 0.3s ease; /* Transição suave */
        }

        button:hover {
            background-color: #0056b3; /* Cor do botão ao passar o mouse */
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Inclusão de clientes</h2>
        <form action="processar_inclusao.php" method="POST">
            <label for="Banco">Selecione uma opção:</label>
            <select name="Banco" id="Banco">
                <?php
                include_once "conexao.php";
                $query = "SELECT id, nome FROM banco";
                $stmt = $conn->prepare($query);
                $stmt->execute();
                $pai = $stmt->fetchAll(PDO::FETCH_ASSOC);
                foreach ($pai as $row) {
                    echo "<option value='{$row['id']}'>{$row['nome']}</option>";
                }
                ?>
            </select>
            <label for="valor">Valor:</label>
            <input type="text" name="valor" id="valor" required>
            <button type="submit">Adicionar</button>
        </form>
    </div>
</body>
</html>
