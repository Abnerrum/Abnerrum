<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Livraria do Abner</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            color: #333;
            text-align: center;
            margin-top: 30px;
        }

        form {
            width: 400px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        select,
        input[type="text"],
        button[type="submit"] {
            width: calc(100% - 10px);
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h2>Empréstimo de Livros</h2>
    <form action="processo.php" method="POST">
        <label for="livro">Selecione o livro:</label>
        <select name="livro" id="livro">
            <?php
            include_once "conexao.php";
            $query = "SELECT id, titulo FROM livro";
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $livros = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($livros as $livro) {
                echo "<option value='{$livro['id']}'>{$livro['titulo']}</option>";
            }
            ?>
        </select>
        <label for="usuario">Seu nome:</label>
        <input type="text" name="usuario" id="usuario" required>
        <button type="submit">Empréstimo</button>
    </form>
</body>
</html>
