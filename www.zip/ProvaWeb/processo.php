<?php
session_start();
include_once "conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $livro_id = $_POST["livro"];
    $usuario = $_POST["usuario"];
    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM livro WHERE id = :livro_id");
    $stmt->bindParam(":livro_id", $livro_id, PDO::PARAM_INT);
    $stmt->execute();
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($resultado["total"] == 0) {
        $_SESSION['msg'] = "Livro não encontrado.";
        header("Location: index.php");
        exit;
    }

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM emprestimolivro WHERE id_usuario = :usuario AND id_livro = :livro_id");
    $stmt->bindParam(":usuario", $usuario, PDO::PARAM_STR);
    $stmt->bindParam(":livro_id", $livro_id, PDO::PARAM_INT);
    $stmt->execute();
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($resultado["total"] >= 3) {
        $_SESSION['msg'] = "Você já pegou este livro emprestado mais de três vezes.";
        header("Location: index.php");
        exit;
    }
$stmt = $conn->prepare("INSERT INTO emprestimolivro (id_usuario, id_livro, data_emprestimo) VALUES (:usuario, :livro_id, NOW())");
    $stmt->bindParam(":usuario", $usuario, PDO::PARAM_STR);
    $stmt->bindParam(":livro_id", $livro_id, PDO::PARAM_INT);
    $stmt->execute();

    $_SESSION['msg'] = "Livro emprestado com sucesso!";
    header("Location: index.php");
} else {
    $_SESSION['msg'] = "Requisição inválida.";
    header("Location: index.php");
}
?>
