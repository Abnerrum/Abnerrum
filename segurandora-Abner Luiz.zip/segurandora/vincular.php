<?php
 include "index.php";
    if(isset($_POST['cliente']) && isset($_POST['seguro'])) {
        $cliente_id = $_POST['cliente'];
        $seguro_id = $_POST['seguro'];

        $conn = new mysqli($servername, $username, $password, $dbname);
        $sql = "INSERT INTO usuario_plano (idusuario, idplano) VALUES ('$cliente_id', '$seguro_id')";

        if ($conn->query($sql) === TRUE) {
            echo "Cliente vinculado ao seguro com sucesso!";
        } else {
            echo "Erro ao vincular cliente ao seguro: " . $conn->error;
        }

        $conn->close();
    
    }
?>
