<html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vinculação de Clientes e Seguros</title>
</head>
<body>
    <h2>Vincular Cliente a Seguro</h2>
    <form action="vincular.php" method="post">
        <label for="cliente">Cliente:</label>
        <select name="cliente" id="cliente">
            <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "seguradora";

                $conn = new mysqli($servername, $username, $password, $dbname);
                if ($conn->connect_error) {
                    die("Erro de conexão: " . $conn->connect_error);
                }
                $sql = "SELECT idusuario, nome_usuario FROM usuario";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row["idusuario"] . "'>" . $row["nome_usuario"] . "</option>";
                    }
                } else {
                    echo "0 resultados";
                }
                $conn->close();
            ?>
        </select>
        <br><br>
        <label for="seguro">Seguro:</label>
        <select name="seguro" id="plano">
            <?php
               include "conexao.php";
               $conn = new mysqli($servername, $username, $password, $dbname); 
                $sql = "SELECT idplano, nome_plano FROM plano";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row["idplano"] . "'>" . $row["nome_plano"] . "</option>";
                    }
                } else {
                    echo "0 resultados";
                }
                $conn->close();
            ?>
        </select>
        <br><br>
        <input type="submit" value="Vincular">
    </form>
    <h2>Desvincular Cliente de Seguro</h2>
    <form action="desvincular.php" method="post">
        <label for="cliente_desv">Cliente:</label>
        <select name="cliente_desv" id="cliente_desv">
            <?php
                $conn = new mysqli($servername, $username, $password, $dbname);
            
                $sql = "SELECT idusuario, nome_usuario FROM usuario";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row["idusuario"] . "'>" . $row["nome_usuario"] . "</option>";
                    }
                } else {
                    echo "0 resultados";
                }
                $conn->close();
            ?>
        </select>
        <br><br>
        <label for="seguro_desv">Seguro:</label>
        <select name="seguro_desv" id="seguro_desv">
            <?php
                $conn = new mysqli($servername, $username, $password, $dbname);
                $sql = "SELECT idplano, nome_plano FROM plano";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row["idplano"] . "'>" . $row["nome_plano"] . "</option>";
                    }
                } else {
                    echo "0 resultados";
                }
                $conn->close();
            ?>
        </select>
        <br><br>
        <input type="submit" value="Desvincular">
    </form>
</body>
</html>
