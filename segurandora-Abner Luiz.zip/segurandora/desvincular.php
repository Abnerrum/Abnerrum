<?php
 include "index.php";
    if(isset($_POST['cliente_desv']) && isset($_POST['seguro_desv'])) {
        $cliente_id = $_POST['cliente_desv'];
        $seguro_id = $_POST['seguro_desv'];

        $conn = new mysqli($servername, $username, $password, $dbname);
        $sql = "DELETE FROM usuario_plano WHERE idusuario = '$cliente_id' AND idplano = '$seguro_id'";

        if ($conn->query($sql) === TRUE) {
            echo "Cliente desvinculado do seguro com sucesso!";
        } else {
            echo "Erro ao desvincular cliente do seguro: " . $conn->error;
        }

        $conn->close();
    }
?>
