<!DOCTYPE html>
<html>
<head>
    <title>Cadastrar Venda</title>
</head>
<body>
    <h1>Cadastrar Venda</h1>
    <form action="inserte.php" method="POST">
        <label>Data:</label>
        <input type="date" name="data" required><br>
        <label>CPF:</label>
        <input type="text" name="cpf" maxlength="100" required><br>
        <label>Produto:</label>
        <select name="id_produto" required>
            <?php include "produtos.php"; ?>
        </select>
        <input type="submit" value="Cadastrar">
    </form>

    <h1> Vendas</h1>
    <table border="1">
        <tr>
            <th>CPF</th>
            <th>NOME DO PRODUTO</th>
            <th>DATA DA COMPRA</th>
        </tr>
        <?php include "vendas.php"; ?>
    </table>
</body>
</html>
