<?php

include "conexao.php";

$query = "SELECT id, nome FROM Produto";
$result = $conn->query($query);
while ($row = $result->fetch_assoc()) {
    echo "<option value='" . $row['id'] . "'>" . $row['nome'] . "</option>";
}
$conn->close();
?>
