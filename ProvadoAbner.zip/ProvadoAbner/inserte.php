<?php
include "conexao.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $data = $_POST['data'];
    $cpf = $_POST['cpf'];
    $id_produto = $_POST['id_produto'];
    $query = "INSERT INTO venda (data, cpf, id_produto) VALUES ('$data', '$cpf', '$id_produto')";
    if ($conn->query($query) === TRUE) {
        echo "Venda cadastrada com sucesso!";
    } else {
        echo "Erro ao cadastrar venda: " . $conn->error;
    }
} else {
   
    echo "Método de requisição inválido.";
}

$conn->close();
header("Location:produtos.php");
?>
