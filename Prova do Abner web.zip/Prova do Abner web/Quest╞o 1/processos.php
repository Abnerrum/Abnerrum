<?php
require('conexao.php');
$id = $_GET['id'];
$sql = "INSERT INTO `loja`.`mercado` (`id`) VALUES ('$id')";
if (mysqli_query($conn, $sql)) {
    echo " encotrado com sucesso";
} else {
    echo "não encotrei: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>

