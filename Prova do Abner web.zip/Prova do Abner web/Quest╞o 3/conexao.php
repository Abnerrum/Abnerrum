<?php
$host = "localhost"; 
$user = "root"; 
$pass = "";         
$dbname = "banco do brasil";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);

    // Configurar o modo de erro para lançar exceções em caso de erros
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    
    echo "Conexão bem-sucedida!";
} catch(PDOException $e) {
    
    echo "Erro na conexão com o banco de dados: " . $e->getMessage();
}
?>
