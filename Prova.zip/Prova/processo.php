<?php
    // Verificação se o formulário foi submetido
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Conexão com o banco de dados
        $conn = new mysqli('localhost', 'root', '', 'Escola');
 
        if ($conn->connect_error) {
            die("Erro ao conectar ao banco de dados: " . $conn->connect_error);
        }
  
        $livroId = $_POST["livro"];
        
        $disponibilidadeQuery = "SELECT disponivel FROM Livros WHERE id = $livroId";
        $disponibilidadeResult = $conn->query($disponibilidadeQuery);

        if ($disponibilidadeResult->num_rows > 0) {
            $disponibilidade = $disponibilidadeResult->fetch_assoc()["disponivel"];

            if ($disponibilidade) {
                $dataEmprestimo = date("Y-m-d");
                $emprestimoQuery = "INSERT INTO Emprestimos (livro_id, data_emprestimo) VALUES ($livroId, '$dataEmprestimo')";
                if ($conn->query($emprestimoQuery) === TRUE) {
                    echo "Livro emprestado com sucesso!";
                } else {
                    echo "Erro ao realizar o empréstimo: " . $conn->error;
                }
            } else {
                echo "O livro selecionado não está disponível para empréstimo.";
            }
        } else {
            echo "Livro não encontrado.";
        }

        $disponibilidadeResult->free_result();
        $conn->close();
    }
?>
