<?php
    // Conexão com o banco de dados
    $conn = new mysqli('localhost', 'root', '', 'Escola');
 
    if ($conn->connect_error) {
        die("Erro ao conectar ao banco de dados: " . $conn->connect_error);
    }

    // Consulta para obter os livros disponíveis
    $livrosQuery = "SELECT id, titulo FROM Livros WHERE disponivel = true";
    $livrosResult = $conn->query($livrosQuery);

    // Exibição das opções do ComboBox com os livros disponíveis
    if ($livrosResult->num_rows > 0) {
        while ($livro = $livrosResult->fetch_assoc()) {
            echo "<option value='" . $livro['id'] . "'>" . $livro['titulo'] . "</option>";
        }
    }

    // Liberação dos recursos
    $livrosResult->free_result();
    $conn->close();
?>
