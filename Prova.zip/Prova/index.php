<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Empréstimo de Livros</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <h1>Empréstimo de Livros</h1>

    <form action="conexao.php" method="post" id="formEmprestimo">
        <label for="livro">Escolha um livro:</label>
        <select name="livro" id="livro" aria-label="Selecione o livro que deseja emprestar" required>
            <!-- As opções do ComboBox com os livros disponíveis serão exibidas aqui -->
        </select>
        <br>
        <input type="submit" value="Pegar emprestado" id="btnEmprestimo" aria-label="Clique para realizar o empréstimo do livro selecionado">
    </form>
</body>
</html>

