<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inclusão de Banco</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Inclusão de clientes</h2>
        <form action="processar_inclusao.php" method="POST">
            <label for="Banco">Selecione uma opção:</label>
            <select name="Banco" id="Banco">
                <?php
                include_once "conexao.php";
                $query = "SELECT id, nome FROM banco";
                $stmt = $conn->prepare($query);
                $stmt->execute();
                $pai = $stmt->fetchAll(PDO::FETCH_ASSOC);
                foreach ($pai as $row) {
                    echo "<option value='{$row['id']}'>{$row['nome']}</option>";
                }
                ?>
            </select>
            <label for="valor">Valor:</label>
            <input type="text" name="valor" id="valor" required>
            <button class="add_btn"type="submit">Adicionar</button>
        </form>
    </div>
</body>
</html>
