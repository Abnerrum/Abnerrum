<?php
require('conexao.php');
$id =  $_GET['id'];
$sql = "DELETE FROM `loja`.`mercado` WHERE (`id` = '$id');";
if (mysqli_query($conn, $sql)) {
      echo "Novo Registro Adicionado";
} else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>
