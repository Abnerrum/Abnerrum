<html>
<head>
    <meta charset="UTF-8">
    <title>Serviço da Empresa Avibras</title>
</head>
<body>
    <form action="delete.php" method="get">
        <h2>Deletar: Serviço da Empresa</h2>
        <label for="id">ID:</label>
        <input type="text" name="id" id="id" required>
        
        <label for="parte">Escolha a parte:</label>
        <select name="" id="" required>
            <option value="Tecnico">Abner</option>
            <option value="Tecnico">Hidroladria</option>
            <option value="Tecnico">Rovilson</option>
            <option value="Tecnico">Helena</option>
            <option value="Tecnico">Lais</option>
            <option value="Tecnico">Luiz</option>
            <option value="Tecnico">Gustavo</option>
            <option value="Tecnico">Elias</option>
            <option value="Tecnico">Mario</option>
            <option value="Tecnico">Pedro</option>
        </select>
        
        <input type="submit" value="Deletar">
    </form>

    <?php
        $servername = "localhost";
        $database = "loja";
        $username = "root";
        $password = "";
        $conn = mysqli_connect($servername, $username, $password, $database);
        if (!$conn) {
            echo "Connection failed: " . mysqli_connect_error();
        } else {
            echo "Conexão com Sucesso!!<br>";
        }
    ?>
</body>
</html>

